﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using MathTaskClassLibrary;

namespace MathTaskClassLibraryTests
{
    [TestClass]
    public class GeometryTests
    {
        [TestMethod]

        public void RectangleArea_3and5_15returned()
        {
            int a = 3;
            int b = 5;
            int expected = 15;

            Geometry g = new Geometry();
            int actual = g.RectangleArea(a, b);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void CylinderVolume_2r_5h_62_8returned()
        {
            int r = 2;
            int h = 5;
            double expected = Math.PI * Math.Pow(r, 2) * h;

            Geometry g = new Geometry();
            double actual = g.CylinderVolume(r, h);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void QuadraticEquation_MinusA_3B_4C_minus1_and_4returned()
        {
            int a = -1;
            int b = 3;
            int c = 4;
            double x1expected = -1;
            double x2expected = 4;

            var q = new Quadratic();
            var actual = q.QuadraticEquation(a, b, c);

            Assert.AreEqual(Tuple.Create(x1expected.ToString(), x2expected.ToString()), actual);
        }
    }
}
