﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MathTaskClassLibrary
{
    public class Geometry
    {
        public int RectangleArea(int a, int b)
        {
            return a * b;
        }

        public double CylinderVolume(int r, int h)
        {
            return Math.PI * Math.Pow(r, 2) * h;
        }
    }
    public class Quadratic
    {
        public Tuple<string, string> QuadraticEquation(double a, double b, double c)
        {
            double discriminant = Math.Pow(b, 2) - 4 * a * c;

            if (discriminant > 0)
            {
                double x1 = (-b + Math.Sqrt(discriminant)) / (2 * a);
                double x2 = (-b - Math.Sqrt(discriminant)) / (2 * a);
                return Tuple.Create(Convert.ToString(x1), Convert.ToString(x2));
            }
            else if (discriminant == 0)
            {
                double x1 = -b / (2 * a);
                return Tuple.Create(Convert.ToString(x1), "null");
            }
            else
            {
                return Tuple.Create("null", "null");
            }
        }
    }
}
